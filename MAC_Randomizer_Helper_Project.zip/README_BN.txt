MAC Randomizer Helper — Android অ্যাপ প্রজেক্ট

ফিচার:
- Wi-Fi সেটিংস খোলার বোতাম
- প্রতি ঘণ্টায় আনুমানিক রিমাইন্ডার চালু/বন্ধ
- MAC Randomization অপশন খুঁজতে বাংলা নির্দেশনা
- ফোন রিস্টার্টের পর রিমাইন্ডার আবার চালু করার চেষ্টা

গুরুত্বপূর্ণ:
- Android অ্যাপটি নিজে MAC Address পরিবর্তন করে না।
- Android AlarmManager-এর inexact repeating alarm-এর কারণে নোটিফিকেশন ঠিক মিনিটে নাও আসতে পারে।
- Android Studio ও SDK দিয়ে build করতে হবে; এই ZIP-এ APK ফাইল নেই।

APK তৈরির ধাপ:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio-তে এই ফোল্ডারটি Open করুন।
3. Gradle sync শেষ হতে দিন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK সাধারণত app/build/outputs/apk/debug/app-debug.apk-এ থাকবে।
6. APK ফোনে কপি করে ইনস্টল করুন। শুধু বিশ্বস্ত নিজের তৈরি APK ইনস্টল করুন।

প্রথমবার অ্যাপ খুলে “প্রতি ঘণ্টার রিমাইন্ডার চালু করুন” চাপুন।
