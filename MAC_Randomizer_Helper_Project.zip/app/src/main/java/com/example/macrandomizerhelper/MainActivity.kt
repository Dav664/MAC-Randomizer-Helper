package com.example.macrandomizerhelper

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
        }

        val title = TextView(this).apply {
            text = "MAC Randomizer Helper"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "\nSamsung Galaxy A10 • Android 11\n\nএই অ্যাপ প্রতি ঘণ্টায় মনে করিয়ে দিতে পারে এবং Wi‑Fi সেটিংস খুলতে সাহায্য করে। Android-এর নিরাপত্তার কারণে অ্যাপটি নিজে MAC Address বদলায় না।\n"
            textSize = 16f
            gravity = Gravity.CENTER
        }
        root.addView(title, match())
        root.addView(description, match())

        root.addView(makeButton("Wi‑Fi সেটিংস খুলুন") {
            try {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }, buttonParams())

        root.addView(makeButton("প্রতি ঘণ্টার রিমাইন্ডার চালু করুন") {
            scheduleReminder()
            Toast.makeText(this, "রিমাইন্ডার চালু করা হয়েছে।", Toast.LENGTH_LONG).show()
        }, buttonParams())

        root.addView(makeButton("রিমাইন্ডার বন্ধ করুন") {
            cancelReminder()
            Toast.makeText(this, "রিমাইন্ডার বন্ধ করা হয়েছে।", Toast.LENGTH_SHORT).show()
        }, buttonParams())

        root.addView(makeButton("MAC Randomization খুঁজবেন যেভাবে") {
            android.app.AlertDialog.Builder(this)
                .setTitle("MAC Randomization")
                .setMessage("১. Settings > Connections > Wi‑Fi খুলুন।\n২. সংযুক্ত Wi‑Fi নেটওয়ার্কের পাশে গিয়ার আইকনে চাপ দিন।\n৩. Advanced বা View more থাকলে খুলুন।\n৪. MAC address type / Randomized MAC অপশন থাকলে সেটি বেছে নিন।\n\nমেনুর নাম One UI সংস্করণ ও নেটওয়ার্ক অনুযায়ী আলাদা হতে পারে।")
                .setPositiveButton("ঠিক আছে", null)
                .show()
        }, buttonParams())

        val footer = TextView(this).apply {
            text = "\nনোট: MAC Address বদলানোর নিশ্চয়তা এই অ্যাপ দেয় না। নেটওয়ার্কের মালিকের অনুমতি নিয়ে Wi‑Fi ব্যবহার করুন।"
            textSize = 13f
            gravity = Gravity.CENTER
        }
        root.addView(footer, match())
        setContentView(root)
    }

    private fun match() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(10) }

    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply { text = label; setOnClickListener { action() } }

    private fun reminderIntent(): PendingIntent {
        val intent = Intent(this, ReminderReceiver::class.java)
        return PendingIntent.getBroadcast(
            this, 1001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun scheduleReminder() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val first = System.currentTimeMillis() + 60 * 60 * 1000L
        alarm.setInexactRepeating(
            AlarmManager.RTC_WAKEUP, first, 60 * 60 * 1000L, reminderIntent()
        )
    }

    private fun cancelReminder() {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(reminderIntent())
    }
}
