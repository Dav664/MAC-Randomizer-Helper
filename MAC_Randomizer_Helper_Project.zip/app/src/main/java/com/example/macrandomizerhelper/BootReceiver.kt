package com.example.macrandomizerhelper

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
            val reminder = Intent(context, ReminderReceiver::class.java)
            val pending = android.app.PendingIntent.getBroadcast(
                context, 1001, reminder,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val first = System.currentTimeMillis() + 60 * 60 * 1000L
            alarm.setInexactRepeating(
                android.app.AlarmManager.RTC_WAKEUP, first, 60 * 60 * 1000L, pending
            )
        }
    }
}
